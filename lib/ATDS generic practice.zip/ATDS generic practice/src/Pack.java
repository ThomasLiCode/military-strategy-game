import java.util.ArrayList;
import java.util.Collections;

public class Pack <T extends Animal>{
    private ArrayList<T> animals;
    public Pack(){
        animals = new ArrayList<>();
    }

    public void addAnimal(T a){
        animals.add(a);
    }

    public void removeAnimal(int i){
        animals.remove(i);
    }

    public void sortByFastest(){
        Collections.sort(animals);
    }

    public String toString(){
        String str = "";
        for(Animal a: animals){
            str += a.getName() + ": " + a.specialAction() + ", ";
        }
        str = str.substring(0, str.length() - 2);
        return str;
    }
}
