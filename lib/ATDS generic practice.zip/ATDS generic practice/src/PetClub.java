import java.util.*;
public class PetClub <T extends Friendly> {
    private List<T> petList;
    private String clubName;

    public PetClub(String clubName, List list){
        this.clubName = clubName;
        petList = list;
    }

    public void addPet(T pet){
        petList.add(pet);
    }

    public void removePet(int i){
        petList.remove(i);
    }

    public String playAll(){
        String rtnStr = "";
        for(T pet: petList){
            rtnStr += pet.toString() + ": " + pet.play() + " , ";
        }
        rtnStr = rtnStr.substring(0, rtnStr.length() - 2);
        return rtnStr;
    }
    public String cuddleAll(){
        String rtnStr = "";
        for(T pet: petList){
            rtnStr += pet.toString() + ": " + pet.cuddle() + " , ";
        }
        rtnStr = rtnStr.substring(0, rtnStr.length() - 2);
        return rtnStr;
    }

    public String toString(){
        String rtnStr = "[" + clubName + "] ";
        for(T pet: petList){
            rtnStr += pet.toString() + ", ";
        }
        rtnStr = rtnStr.substring(0, rtnStr.length() - 2);
        return rtnStr;
    }
}
