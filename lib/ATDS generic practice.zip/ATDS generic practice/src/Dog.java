public class Dog extends Animal implements Friendly {
    public Dog(String n, String d, double s){
        super(n, d, s);
    }
    public String specialAction(){
        return "woof";
    }

    public String cuddle(){
        return this.getName() + " jumps on your lap! Awww!";
    }

    public String play(){
        return this.getName() + " goes for the ball!";
    }

}
