public class Cat extends Animal implements Friendly{
    public Cat(String n, String d, double s){
        super(n, d, s);
    }
    public String specialAction(){
        return "meow";
    }

    public String cuddle(){
        return this.getName() + " nuzzles your against your shoulder! Awwww!";
    }

    public String play(){
        return this.getName() + " chases the cat toy!";
    }
}
