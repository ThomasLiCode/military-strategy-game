import java.util.*;

public class PetParty <T extends Friendly>{

    private Collection<T> petList;

    public PetParty(Collection<T> list){
        petList = list;
    }

    public void addPet(T pet){
        petList.add(pet);
    }

    public void removePet(int i){
        Iterator<T> iter = petList.iterator();
        int count = -1;
        while(iter.hasNext()){
            if(count == i){
                iter.remove();
            }
            count++;
            iter.next();
        }
    }

    public String playAll(){
        String rtnStr = "";
        for(T pet: petList){
            rtnStr += pet.toString() + ": " + pet.play() + " , ";
        }
        rtnStr = rtnStr.substring(0, rtnStr.length() - 2);
        return rtnStr;
    }
    public String cuddleAll(){
        String rtnStr = "";
        for(T pet: petList){
            rtnStr += pet.toString() + ": " + pet.cuddle() + " , ";
        }
        rtnStr = rtnStr.substring(0, rtnStr.length() - 2);
        return rtnStr;
    }

    public String toString(){
        String rtnStr = "";
        for(T pet: petList){
            rtnStr += pet.toString() + ", ";
        }
        rtnStr = rtnStr.substring(0, Math.max(0, rtnStr.length() - 2));
        return rtnStr;
    }
}
