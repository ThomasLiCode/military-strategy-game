public interface Friendly {

    public String cuddle();

    public String play();
}
