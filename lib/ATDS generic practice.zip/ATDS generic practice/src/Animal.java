public abstract class Animal implements Comparable<Animal>{
    private String name;
    private String diet;
    private double speed;

    public Animal(String n, String d, double s){
        name = n;
        diet = d;
        speed = s;
    }

    public String getName(){
        return name;
    }

    public String getDiet(){
        return diet;
    }

    public double getSpeed(){
        return speed;
    }
    public abstract String specialAction();

    public int compareTo(Animal a){
        if(speed == a.getSpeed()){
            return 0;
        }else if(speed > a.getSpeed()){
            return -1;
        }else{
            return 1;
        }
    }

    public String toString(){
        return "{" + name + " Speed: " + speed + " Diet: " + diet + "}";
    }

}
