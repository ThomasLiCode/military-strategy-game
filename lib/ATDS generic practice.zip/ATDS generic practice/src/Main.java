import java.util.*;

public class Main {
    public static void main(String[] args) {
        Dog d1 = new Dog("Todd", "Meat", 15);
        Dog d2 = new Dog("Jack", "Meat", 12);
        Dog d3 = new Dog("Jerry", "Meat", 18);
        Pack<Dog> dogPack = new Pack<>();
        dogPack.addAnimal(d1);
        dogPack.addAnimal(d2);
        dogPack.addAnimal(d3);
        System.out.println("before sorting: ");
        System.out.println(dogPack);
        System.out.println("after sorting: ");
        dogPack.sortByFastest();
        System.out.println(dogPack);
        System.out.println();
        LinkedList<Dog> dogList = new LinkedList<>();
        PetClub<Dog> dogPetClub = new PetClub<>("Doggie Pet Club", dogList);
        dogPetClub.addPet(d1);
        dogPetClub.addPet(d2);
        dogPetClub.addPet(d3);
        System.out.println("testing petClub: ");
        System.out.println(dogPetClub);
        System.out.println(dogPetClub.cuddleAll());
        System.out.println();
        System.out.println("testing a cat and dog petClub: ");
        ArrayList<Friendly> friendlyList = new ArrayList<>();
        PetClub<Friendly> friendlyPetClub = new PetClub<>("Friendly Pet Club", friendlyList);
        Cat c1 = new Cat("Tom", "Meat", 15);
        Cat c2 = new Cat("Ari", "Fish", 12);
        Cat c3 = new Cat("Zona", "Catnip", 18);
        friendlyPetClub.addPet(d1);
        friendlyPetClub.addPet(d2);
        friendlyPetClub.addPet(d3);
        friendlyPetClub.addPet(c1);
        friendlyPetClub.addPet(c2);
        friendlyPetClub.addPet(c3);
        System.out.println(friendlyPetClub);
        System.out.println(friendlyPetClub.cuddleAll());
        System.out.println();
        System.out.println("testing petParty");
        TreeSet<Friendly> friendlyTreeSet = new TreeSet<>();
        PetParty<Friendly> friendlyPetParty = new PetParty<>(friendlyList);
        friendlyPetClub.addPet(d1);
        friendlyPetClub.addPet(d2);
        friendlyPetClub.addPet(d3);
        friendlyPetClub.addPet(c1);
        friendlyPetClub.addPet(c2);
        friendlyPetClub.addPet(c3);
        friendlyPetParty.removePet(0);
        System.out.println(friendlyPetParty);





    }
}